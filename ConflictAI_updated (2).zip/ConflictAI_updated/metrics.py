"""
Performance-evaluation metrics shared by every solver path (plain
LaCAM/CBS from key 3, and the Hybrid ML-CBS pipeline from key 5), so
performance_report.py always gets the same shape of data no matter
which solver produced it.

Runtime, Makespan, Sum of Costs, CBS/LaCAM/ML timing, and (for the
hybrid pipeline) rounds/conflicts-resolved are already tracked where
each solver runs (lacam.py, hybrid_solver.py). This module covers the
three metrics that are naturally computed *from the paths themselves*
rather than during the search:

  path_lengths(paths)          -> per-agent path length
  waiting_time(paths)          -> total + per-agent "stayed put" steps
  count_initial_conflicts(...) -> how conflict-heavy the raw instance
                                   is, independent of which solver
                                   later resolves it

It also provides the terminal-facing side of the "seven headline
metrics" (Makespan, Sum of Cost, Runtime, Expanded Nodes, Number of
Conflicts, Replanning Count, Memory Usage):

  track_memory()      -> context manager wrapping tracemalloc, so
                          "Memory Usage" measures the peak memory the
                          solver itself allocated for this run, not
                          the whole pygame process
  print_metrics_report(...) -> the terminal printout, called from
                          main.py right after every solve (key 3 / 5)
"""

import tracemalloc
from contextlib import contextmanager
from itertools import combinations

from astar import astar


def path_lengths(paths):
    """Number of cells each agent's path visits (its length as a list,
    including the start cell). Makespan = max(path_lengths) - 1."""
    return [len(p) for p in paths]


def waiting_time(paths):
    """How many timesteps each agent spent standing still (path[t] ==
    path[t-1]) - a standard MAPF solution-quality metric alongside
    makespan/sum-of-costs: two solutions can share the same makespan
    but one may have agents idling far more than the other.

    Returns (total_wait, per_agent_wait_list).
    """
    per_agent = []
    for p in paths:
        waits = sum(1 for t in range(1, len(p)) if p[t] == p[t - 1])
        per_agent.append(waits)
    return sum(per_agent), per_agent


def count_initial_conflicts(grid, agents, directions):
    """Plan every agent's own shortest path *independently* (ignoring
    every other agent, i.e. before any conflict resolution has
    happened), then count every vertex/edge conflict across the whole
    horizon.

    This is deliberately solver-agnostic: it only depends on the
    grid/start/goal layout, not on whether LaCAM, CBS, or the hybrid
    pipeline ends up solving it - so "Number of Conflicts" is
    comparable across different runs/solvers on the same instance,
    the same way "Runtime" or "Makespan" are.

    Returns None if some agent has no path at all even with every
    other agent ignored (a fully blocked start/goal).
    """
    naive_paths = []
    for i, a in enumerate(agents):
        p = astar(grid, i, a["start"], a["goal"], [], directions)
        if p is None:
            return None
        naive_paths.append(p)

    if not naive_paths:
        return 0

    maxlen = max(len(p) for p in naive_paths)
    n = len(naive_paths)
    total = 0

    for t in range(maxlen):
        # Vertex conflicts: every pair of agents sharing a cell at time t.
        occupied = {}
        for i, p in enumerate(naive_paths):
            pos = p[min(t, len(p) - 1)]
            occupied.setdefault(pos, []).append(i)
        for cell_agents in occupied.values():
            if len(cell_agents) > 1:
                total += len(list(combinations(cell_agents, 2)))

        # Edge conflicts: two agents swapping places across t-1 -> t.
        if t > 0:
            for i, j in combinations(range(n), 2):
                p1, p2 = naive_paths[i], naive_paths[j]
                a1 = p1[min(t - 1, len(p1) - 1)]
                a2 = p1[min(t, len(p1) - 1)]
                b1 = p2[min(t - 1, len(p2) - 1)]
                b2 = p2[min(t, len(p2) - 1)]
                if a1 == b2 and b1 == a2 and a1 != a2:
                    total += 1

    return total


@contextmanager
def track_memory():
    """Context manager measuring peak memory allocated by the code
    inside the `with` block, via tracemalloc (stdlib, cross-platform -
    unlike resource.getrusage, this also works on Windows).

    Usage:
        with track_memory() as mem:
            paths, used, timing = solve(grid, agents)
        mem["peak_kb"]  # peak allocation during the block, in KiB

    Nests safely: if tracemalloc is already running (e.g. this block
    is entered from inside another tracked block), we don't stop it
    underneath the outer caller - we just snapshot around our own
    section instead of calling start()/stop().
    """
    already_tracing = tracemalloc.is_tracing()
    if not already_tracing:
        tracemalloc.start()
    else:
        tracemalloc.reset_peak()

    mem = {"peak_kb": 0.0}
    try:
        yield mem
    finally:
        _current, peak = tracemalloc.get_traced_memory()
        mem["peak_kb"] = peak / 1024.0
        if not already_tracing:
            tracemalloc.stop()


def print_metrics_report(
    solver_name,
    makespan,
    sum_of_cost,
    runtime_seconds,
    expanded_nodes,
    num_conflicts,
    replanning_count,
    memory_kb,
    solved=True,
):
    """Print the seven headline metrics to the terminal. Called from
    main.py right after every solve (key 3 = LaCAM, key 5 = Hybrid
    ML-CBS), so a run's numbers are always visible in the console
    regardless of whether the Performance Report window (key P) is
    ever opened."""

    def fmt(value, suffix=""):
        if value is None:
            return "n/a"
        if isinstance(value, float):
            return f"{value:.4f}{suffix}"
        return f"{value}{suffix}"

    width = 42
    print()
    print("=" * width)
    print(f" MAPF Run Metrics - {solver_name}" + ("" if solved else "  [NO SOLUTION]"))
    print("-" * width)
    print(f" Makespan            : {fmt(makespan)}")
    print(f" Sum of Cost          : {fmt(sum_of_cost)}")
    print(f" Runtime              : {fmt(runtime_seconds, 's')}")
    print(f" Expanded Nodes       : {fmt(expanded_nodes)}")
    print(f" Number of Conflicts  : {fmt(num_conflicts)}")
    print(f" Replanning Count     : {fmt(replanning_count)}")
    print(f" Memory Usage         : {fmt(memory_kb, ' KB')}")
    print("=" * width)
    print()
