"""
The hybrid ML-guided solver - this file *is* the pipeline diagram:

    Warehouse/Grid
        |
        v
      LaCAM  (fast initial paths per agent)
        |
        v
    Initial Paths
        |
        v
    Conflict Detection
        |
        v
    Feature Extraction
        |
        v
    Random Forest
        |
        v
    Conflict Priority Prediction
        |
        v
    CBS Conflict Resolution
        |
        v
    Updated Paths
        |
        v
    Conflict Free? --No--> (back to Conflict Detection)
        |
       Yes
        |
        v
    Final Solution
        |
        v
    Performance Analysis

Each round: detect every conflict at the earliest conflicting timestep,
score all of them with the Random Forest (falling back to the same
heuristic used to train it if no model file has been trained yet), take
the single highest-priority conflict, and resolve it the CBS way - try
constraining each of its two agents and replan that agent with A*,
keeping whichever branch produced the lower-cost path set. Repeat until
conflict-free, or fall back to full CBS if the greedy loop stalls or
runs too long (mirrors the existing LaCAM -> CBS fallback pattern).
"""

import time

from astar import astar
from cbs import cbs as run_full_cbs
from conflict_detection import detect_all_conflicts, make_constraint
from ml_priority import select_priority_conflict

MAX_ROUNDS = 150

# If the *same* pair of agents keeps producing a conflict this many
# rounds in a row, the greedy one-branch-at-a-time approach is almost
# certainly stuck oscillating (e.g. one agent parked on its goal cell
# while another repeatedly needs to pass through) rather than making
# real progress - it's faster and more honest to hand off to full CBS
# than to keep burning rounds hoping it self-resolves.
STAGNATION_LIMIT = 6


def _initial_paths(grid, agents):
    """'LaCAM' stage: each agent's own shortest path, ignoring every
    other agent. Fast, but not guaranteed conflict-free - that's what
    the rest of the pipeline is for."""
    paths = []
    for i, a in enumerate(agents):
        p = astar(grid, i, a["start"], a["goal"], [])
        if p is None:
            return None
        paths.append(p)
    return paths


def solve_hybrid(grid, agents, max_rounds=MAX_ROUNDS):
    """
    Returns (paths, analysis) where analysis is a dict describing what
    happened, suitable for a "Performance Analysis" panel:

      rounds            - number of conflict-resolution rounds run
      conflicts_resolved- number of conflicts actually resolved
      fell_back_to_cbs  - True if the greedy loop gave up and handed
                          off to full CBS for completeness
      model_source      - "rf" if a trained model was used, else
                          "heuristic"
      makespan / sum_of_costs - of the final solution
      log               - per-round trace (conflict type, agents
                          involved, RF priority score, chosen
                          resolution) for display/debugging
      elapsed_seconds
    """
    start_time = time.time()
    log = []
    model_source = "heuristic"

    if not agents:
        return [], {
            "rounds": 0, "conflicts_resolved": 0, "fell_back_to_cbs": False,
            "model_source": model_source, "makespan": 0, "sum_of_costs": 0,
            "log": log, "elapsed_seconds": 0.0,
        }

    paths = _initial_paths(grid, agents)
    if paths is None:
        return None, {
            "rounds": 0, "conflicts_resolved": 0, "fell_back_to_cbs": False,
            "model_source": model_source, "makespan": None, "sum_of_costs": None,
            "log": log, "elapsed_seconds": time.time() - start_time,
        }

    constraints = []
    resolved_count = 0
    fell_back = False

    last_signature = None
    stagnation = 0

    round_num = 0
    while round_num < max_rounds:
        conflicts = detect_all_conflicts(paths)
        if not conflicts:
            break

        round_num += 1
        conflict, features, score, model_source, _scored = select_priority_conflict(
            conflicts, paths, grid
        )

        signature = (conflict["type"], min(conflict["a1"], conflict["a2"]), max(conflict["a1"], conflict["a2"]))
        if signature == last_signature:
            stagnation += 1
        else:
            stagnation = 0
        last_signature = signature

        if stagnation >= STAGNATION_LIMIT:
            fell_back = True
            break

        candidates = []
        for agent in (conflict["a1"], conflict["a2"]):
            constraint = make_constraint(agent, conflict)
            new_constraints = constraints + [constraint]
            p = astar(grid, agent, agents[agent]["start"], agents[agent]["goal"], new_constraints)
            if p is not None:
                trial_paths = list(paths)
                trial_paths[agent] = p
                cost = sum(len(x) for x in trial_paths)
                candidates.append((cost, agent, p, new_constraints))

        if not candidates:
            fell_back = True
            break

        candidates.sort(key=lambda x: x[0])
        _, agent, p, new_constraints = candidates[0]
        paths[agent] = p
        constraints = new_constraints
        resolved_count += 1

        log.append({
            "round": round_num,
            "conflict_type": conflict["type"],
            "agent1": conflict["a1"],
            "agent2": conflict["a2"],
            "priority_score": round(score, 3),
            "model_source": model_source,
            "conflicts_seen_this_round": len(conflicts),
            "resolved_agent": agent,
        })
    else:
        fell_back = True

    if fell_back:
        fallback_paths = run_full_cbs(grid, agents)
        elapsed = time.time() - start_time
        if fallback_paths is None:
            return None, {
                "rounds": round_num, "conflicts_resolved": resolved_count,
                "fell_back_to_cbs": True, "model_source": model_source,
                "makespan": None, "sum_of_costs": None, "log": log,
                "elapsed_seconds": elapsed,
            }
        makespan = max(len(p) for p in fallback_paths) - 1
        sum_of_costs = sum(len(p) for p in fallback_paths)
        return fallback_paths, {
            "rounds": round_num, "conflicts_resolved": resolved_count,
            "fell_back_to_cbs": True, "model_source": model_source,
            "makespan": makespan, "sum_of_costs": sum_of_costs, "log": log,
            "elapsed_seconds": elapsed,
        }

    makespan = max(len(p) for p in paths) - 1
    sum_of_costs = sum(len(p) for p in paths)
    elapsed = time.time() - start_time
    return paths, {
        "rounds": round_num, "conflicts_resolved": resolved_count,
        "fell_back_to_cbs": False, "model_source": model_source,
        "makespan": makespan, "sum_of_costs": sum_of_costs, "log": log,
        "elapsed_seconds": elapsed,
    }
