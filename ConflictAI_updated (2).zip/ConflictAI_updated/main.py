import pygame

from config import (
    GRID_ROWS,
    GRID_COLS,
    CELL_SIZE,
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    GRID_WIDTH,
    FPS,
    DIRECTIONS_4,
    DIRECTIONS_8,
)
from ui import draw_screen
from lacam import solve
from hybrid_solver import solve_hybrid
from distance_table import find_unreachable_agent
from metrics import count_initial_conflicts, waiting_time, path_lengths, track_memory, print_metrics_report
from performance_report import show_performance_report
from benchmark_report import run_benchmark, show_benchmark_report

pygame.init()

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("MAPF - LaCAM / Hybrid ML-CBS Simulator")

clock = pygame.time.Clock()

grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]
agents = []
temp = {}

mode = "Obstacle"
animating = False
show_stats = True
frame = 0
running = True
status_message = "Click grid to place obstacles. Press 2 to add agents."
solver_used = ""
analysis = None

NUM_KEYS = {
    pygame.K_1: 1, pygame.K_KP1: 1,
    pygame.K_2: 2, pygame.K_KP2: 2,
    pygame.K_3: 3, pygame.K_KP3: 3,
    pygame.K_4: 4, pygame.K_KP4: 4,
    pygame.K_5: 5, pygame.K_KP5: 5,
}

while running:
    clock.tick(FPS)

    if animating:
        valid = [a for a in agents if "path" in a]
        if valid:
            frame += 1
            mx = max(len(a["path"]) for a in valid)
            if frame >= mx:
                animating = False
        else:
            animating = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            key_num = NUM_KEYS.get(event.key)

            if key_num == 1:
                mode = "Obstacle"
                status_message = "Mode: Obstacle. Click cells to toggle walls."

            elif key_num == 2:
                mode = "Start"
                status_message = "Mode: Start. Click a cell to place agent start."

            elif key_num == 3:
                if len(agents) == 0:
                    status_message = "No agents yet - press 2 and click start/goal first."
                else:
                    for a in agents:
                        a.pop("path", None)
                    solve_stats = {"expanded_nodes": 0, "replanning_count": 0}
                    with track_memory() as mem:
                        paths, used, timing = solve(grid, agents, stats=solve_stats)
                    solver_used = used or ""
                    directions_used = DIRECTIONS_8 if "(diagonal)" in (used or "") else DIRECTIONS_4
                    expanded_nodes = solve_stats.get("expanded_nodes", 0)
                    replanning_count = solve_stats.get("replanning_count", 0)
                    if paths:
                        for i, p in enumerate(paths):
                            agents[i]["path"] = p
                        total_wait, _ = waiting_time(paths)
                        makespan = max(len(p) for p in paths) - 1
                        sum_of_costs = sum(len(p) for p in paths)
                        runtime = timing["lacam_time"] + timing["cbs_time"]
                        num_conflicts = count_initial_conflicts(grid, agents, directions_used)
                        analysis = {
                            "rounds": "n/a", "conflicts_resolved": "n/a",
                            "fell_back_to_cbs": "CBS" in (used or ""),
                            "model_source": "n/a",
                            "makespan": makespan,
                            "sum_of_costs": sum_of_costs,
                            "directions": "8-direction (diagonal)" if "(diagonal)" in (used or "") else "4-direction",
                            "log": [],
                            "elapsed_seconds": runtime,
                            "lacam_time": timing["lacam_time"], "cbs_time": timing["cbs_time"],
                            "ml_prediction_time": 0.0,
                            "num_conflicts": num_conflicts,
                            "waiting_time": total_wait,
                            "path_lengths": path_lengths(paths),
                            "expanded_nodes": expanded_nodes, "replanning_count": replanning_count,
                            "memory_kb": mem["peak_kb"],
                            "solved": True, "failure_reason": None,
                        }
                        status_message = f"{used} solved: {len(agents)} agent(s), cost {sum(len(p) for p in paths)}."
                        print_metrics_report(
                            solver_used, makespan, sum_of_costs, runtime,
                            expanded_nodes, num_conflicts, replanning_count, mem["peak_kb"],
                            solved=True,
                        )
                    else:
                        trapped = find_unreachable_agent(grid, agents)
                        if trapped is not None:
                            reason = (
                                f"Agent {trapped + 1}'s start and goal aren't connected - "
                                f"walls fully block any path."
                            )
                        else:
                            reason = (
                                f"LaCAM and its CBS fallback both failed to find a conflict-free "
                                f"solution (CBS ran for {timing['cbs_time']:.1f}s)."
                            )
                        runtime = timing["lacam_time"] + timing["cbs_time"]
                        analysis = {
                            "rounds": "n/a", "conflicts_resolved": "n/a",
                            "fell_back_to_cbs": True, "model_source": "n/a",
                            "makespan": None, "sum_of_costs": None,
                            "directions": "8-direction (diagonal)", "log": [],
                            "elapsed_seconds": runtime,
                            "lacam_time": timing["lacam_time"], "cbs_time": timing["cbs_time"],
                            "ml_prediction_time": 0.0,
                            "num_conflicts": None, "waiting_time": None, "path_lengths": None,
                            "expanded_nodes": expanded_nodes, "replanning_count": replanning_count,
                            "memory_kb": mem["peak_kb"],
                            "solved": False, "failure_reason": reason,
                        }
                        if trapped is not None:
                            status_message = reason + " Clear some obstacles (mode 1)."
                        else:
                            status_message = "No solution found (LaCAM and CBS fallback both failed)."
                        print_metrics_report(
                            solver_used or "LaCAM", None, None, runtime,
                            expanded_nodes, None, replanning_count, mem["peak_kb"],
                            solved=False,
                        )

            elif key_num == 4:
                ok = any("path" in a for a in agents)
                if not ok:
                    status_message = "No solved paths yet - press 3 to run LaCAM first."
                else:
                    frame = 0
                    animating = True
                    status_message = "Animating..."

            elif key_num == 5:
                if len(agents) == 0:
                    status_message = "No agents yet - press 2 and click start/goal first."
                else:
                    for a in agents:
                        a.pop("path", None)
                    with track_memory() as mem:
                        paths, analysis = solve_hybrid(grid, agents)
                    analysis["memory_kb"] = mem["peak_kb"]
                    diagonal_note = " (diagonal)" if analysis.get("directions", "").startswith("8") else ""
                    if analysis["fell_back_to_cbs"]:
                        solver_used = f"Hybrid (fell back to CBS){diagonal_note}"
                    else:
                        solver_used = f"Hybrid ({analysis['model_source']} priority){diagonal_note}"
                    print_metrics_report(
                        solver_used,
                        analysis.get("makespan"),
                        analysis.get("sum_of_costs"),
                        analysis.get("elapsed_seconds"),
                        analysis.get("expanded_nodes"),
                        analysis.get("num_conflicts"),
                        analysis.get("replanning_count"),
                        mem["peak_kb"],
                        solved=analysis.get("solved", True),
                    )
                    if paths:
                        for i, p in enumerate(paths):
                            agents[i]["path"] = p
                        status_message = (
                            f"{solver_used}: {analysis['rounds']} round(s), "
                            f"{analysis['conflicts_resolved']} conflict(s) resolved, "
                            f"cost {analysis['sum_of_costs']}."
                        )
                    else:
                        trapped = find_unreachable_agent(grid, agents)
                        if trapped is not None:
                            status_message = (
                                f"Agent {trapped + 1}'s start and goal aren't connected - "
                                f"walls fully block any path. Clear some obstacles (mode 1)."
                            )
                        else:
                            status_message = analysis.get("failure_reason") or (
                                "No solution found (Hybrid pipeline and CBS fallback both failed)."
                            )

            elif event.key == pygame.K_g:
                show_stats = not show_stats
                status_message = f"Graph panel {'shown' if show_stats else 'hidden'}."

            elif event.key == pygame.K_p:
                if analysis is None:
                    status_message = "No run yet - press 3 (LaCAM) or 5 (Hybrid ML-CBS) first."
                else:
                    status_message = "Performance report opened in a separate window - close it to return here."
                    draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message, solver_used, analysis)
                    pygame.display.flip()
                    show_performance_report(analysis, solver_used)

            elif event.key == pygame.K_b:
                def _progress(done, total):
                    msg = f"Benchmarking... {done}/{total} agent counts done. Window will pop up when finished."
                    draw_screen(screen, grid, agents, mode, animating, frame, show_stats, msg, solver_used, analysis)
                    pygame.display.flip()
                    for e in pygame.event.get(pygame.QUIT):
                        pass  # keep the window responsive to a close click while we crunch numbers

                status_message = "Benchmarking CBS vs LaCAM across agent counts on the current grid... this may take a bit."
                draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message, solver_used, analysis)
                pygame.display.flip()
                results = run_benchmark(grid, progress_callback=_progress)
                status_message = "Benchmark report opened in a separate window - close it to return here."
                draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message, solver_used, analysis)
                pygame.display.flip()
                show_benchmark_report(results)

            elif event.key == pygame.K_r:
                grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]
                agents.clear()
                temp.clear()
                mode = "Obstacle"
                animating = False
                frame = 0
                solver_used = ""
                analysis = None
                status_message = "Reset: grid and agents cleared."

        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = pygame.mouse.get_pos()
            if x >= GRID_WIDTH:
                continue

            row = y // CELL_SIZE
            col = x // CELL_SIZE

            if row >= GRID_ROWS or col >= GRID_COLS:
                continue

            if mode == "Obstacle":
                grid[row][col] = 1 - grid[row][col]

            elif mode == "Start":
                temp["start"] = (row, col)
                mode = "Goal"
                status_message = f"Start set at {(row, col)}. Now click a goal cell."

            elif mode == "Goal":
                temp["goal"] = (row, col)
                agents.append(temp.copy())
                temp.clear()
                mode = "Obstacle"
                status_message = f"Agent {len(agents)} added. Press 2 to add another, 3 for LaCAM, or 5 for Hybrid ML-CBS."

    draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message, solver_used, analysis)

pygame.quit()
