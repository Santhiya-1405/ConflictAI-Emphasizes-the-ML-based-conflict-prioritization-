"""
The hybrid ML-guided solver - this file *is* the pipeline diagram:

    Warehouse/Grid
        |
        v
      LaCAM  (fast initial paths per agent)
        |
        v
    Initial Paths
        |
        v
    Conflict Detection
        |
        v
    Feature Extraction
        |
        v
    Random Forest
        |
        v
    Conflict Priority Prediction
        |
        v
    CBS Conflict Resolution
        |
        v
    Updated Paths
        |
        v
    Conflict Free? --No--> (back to Conflict Detection)
        |
       Yes
        |
        v
    Final Solution
        |
        v
    Performance Analysis

Each round: detect every conflict at the earliest conflicting timestep,
score all of them with the Random Forest (falling back to the same
heuristic used to train it if no model file has been trained yet), take
the single highest-priority conflict, and resolve it the CBS way - try
constraining each of its two agents and replan that agent with A*,
keeping whichever branch produced the lower-cost path set. Repeat until
conflict-free, or fall back to full CBS if the greedy loop stalls or
runs too long (mirrors the existing LaCAM -> CBS fallback pattern).
"""

import time

from astar import astar
from cbs import cbs as run_full_cbs, DEFAULT_MAX_SECONDS as CBS_MAX_SECONDS
from conflict_detection import detect_all_conflicts, make_constraint
from ml_priority import select_priority_conflict
from metrics import count_initial_conflicts, waiting_time as compute_waiting_time, path_lengths as compute_path_lengths
from config import DIRECTIONS_4, DIRECTIONS_8

MAX_ROUNDS = 150

# If the *same* pair of agents keeps producing a conflict this many
# rounds in a row, the greedy one-branch-at-a-time approach is almost
# certainly stuck oscillating (e.g. one agent parked on its goal cell
# while another repeatedly needs to pass through) rather than making
# real progress - it's faster and more honest to hand off to full CBS
# than to keep burning rounds hoping it self-resolves.
STAGNATION_LIMIT = 6


def _initial_paths(grid, agents, directions=DIRECTIONS_4):
    """'LaCAM' stage: each agent's own shortest path, ignoring every
    other agent. Fast, but not guaranteed conflict-free - that's what
    the rest of the pipeline is for."""
    paths = []
    for i, a in enumerate(agents):
        p = astar(grid, i, a["start"], a["goal"], [], directions)
        if p is None:
            return None
        paths.append(p)
    return paths


def solve_hybrid(grid, agents, max_rounds=MAX_ROUNDS):
    """
    Public entry point used by the UI.

    4-directional movement is tried first, since it's the default,
    more "physical" movement model. Only if the whole pipeline
    (including its full-CBS fallback) fails under that model do we
    widen to 8-directional (diagonal) movement and re-run the entire
    pipeline from scratch. When that's what it took, the returned
    analysis dict's "directions" key says so.

    Returns (paths, analysis) where analysis is a dict describing what
    happened, suitable for a "Performance Analysis" panel:

      rounds            - number of conflict-resolution rounds run
      conflicts_resolved- number of conflicts actually resolved
      fell_back_to_cbs  - True if the greedy loop gave up and handed
                          off to full CBS for completeness
      model_source      - "rf" if a trained model was used, else
                          "heuristic"
      makespan / sum_of_costs - of the final solution
      directions        - "4-direction" or "8-direction (diagonal)",
                          whichever movement model produced the result
      log               - per-round trace (conflict type, agents
                          involved, RF priority score, chosen
                          resolution) for display/debugging
      elapsed_seconds   - total wall-clock time for this pass
      lacam_time        - seconds spent on the initial "LaCAM" stage
                          (independent shortest path per agent)
      cbs_time          - seconds spent on CBS-style conflict
                          resolution (per-round A* replans, plus any
                          full-CBS fallback)
      ml_prediction_time- seconds spent scoring conflicts with the
                          Random Forest / heuristic fallback
      num_conflicts     - conflicts present in the *naive* independent
                          paths, before any resolution (instance
                          difficulty, solver-agnostic)
      waiting_time      - total "stayed put" steps across all agents
                          in the final solution
      path_lengths      - per-agent path length in the final solution
      expanded_nodes    - number of high-level search nodes expanded:
                          greedy resolution rounds, plus (if the
                          pipeline fell back) full CBS's own expanded
                          node count
      replanning_count  - number of individual A* replan calls made:
                          per-round candidate replans, plus (if the
                          pipeline fell back) full CBS's own replan
                          count
      solved            - False if no conflict-free solution was found
                          at all (even after the CBS fallback), True
                          otherwise
      failure_reason    - human-readable reason when solved is False
                          (e.g. CBS hit its time budget, or some
                          agent's start/goal is fully walled off)
    """
    for directions, label in ((DIRECTIONS_4, "4-direction"), (DIRECTIONS_8, "8-direction (diagonal)")):
        paths, analysis = _solve_hybrid_pass(grid, agents, max_rounds, directions)
        analysis["directions"] = label
        if paths is not None:
            return paths, analysis

    return None, analysis


def _solve_hybrid_pass(grid, agents, max_rounds, directions):
    """Runs the full hybrid pipeline (greedy RF-guided resolution, with
    a full-CBS fallback) once, under a single fixed movement model.
    Returns (paths, analysis) - paths is None if even the CBS fallback
    couldn't solve the instance under this movement model."""
    start_time = time.time()
    log = []
    model_source = "heuristic"
    lacam_time = 0.0
    cbs_time = 0.0
    ml_time = 0.0

    if not agents:
        return [], {
            "rounds": 0, "conflicts_resolved": 0, "fell_back_to_cbs": False,
            "model_source": model_source, "makespan": 0, "sum_of_costs": 0,
            "log": log, "elapsed_seconds": 0.0,
            "lacam_time": 0.0, "cbs_time": 0.0, "ml_prediction_time": 0.0,
            "num_conflicts": 0, "waiting_time": 0, "path_lengths": [],
            "expanded_nodes": 0, "replanning_count": 0,
            "solved": True, "failure_reason": None,
        }

    t0 = time.perf_counter()
    paths = _initial_paths(grid, agents, directions)
    lacam_time += time.perf_counter() - t0
    if paths is None:
        return None, {
            "rounds": 0, "conflicts_resolved": 0, "fell_back_to_cbs": False,
            "model_source": model_source, "makespan": None, "sum_of_costs": None,
            "log": log, "elapsed_seconds": time.time() - start_time,
            "lacam_time": lacam_time, "cbs_time": 0.0, "ml_prediction_time": 0.0,
            "num_conflicts": None, "waiting_time": None, "path_lengths": None,
            "expanded_nodes": 0, "replanning_count": 0,
            "solved": False,
            "failure_reason": "At least one agent's start/goal is fully blocked by obstacles - no path exists even ignoring every other agent.",
        }

    # Solver-agnostic "how conflict-heavy is this instance" metric,
    # computed once from the raw naive paths - not affected by
    # whichever resolution strategy runs next.
    num_conflicts = count_initial_conflicts(grid, agents, directions)

    constraints = []
    resolved_count = 0
    replan_calls = 0
    fell_back = False

    last_signature = None
    stagnation = 0

    round_num = 0
    while round_num < max_rounds:
        conflicts = detect_all_conflicts(paths)
        if not conflicts:
            break

        round_num += 1
        t0 = time.perf_counter()
        conflict, features, score, model_source, _scored = select_priority_conflict(
            conflicts, paths, grid
        )
        ml_time += time.perf_counter() - t0

        signature = (conflict["type"], min(conflict["a1"], conflict["a2"]), max(conflict["a1"], conflict["a2"]))
        if signature == last_signature:
            stagnation += 1
        else:
            stagnation = 0
        last_signature = signature

        if stagnation >= STAGNATION_LIMIT:
            fell_back = True
            break

        t0 = time.perf_counter()
        candidates = []
        for agent in (conflict["a1"], conflict["a2"]):
            constraint = make_constraint(agent, conflict)
            new_constraints = constraints + [constraint]
            p = astar(grid, agent, agents[agent]["start"], agents[agent]["goal"], new_constraints, directions)
            replan_calls += 1
            if p is not None:
                trial_paths = list(paths)
                trial_paths[agent] = p
                cost = sum(len(x) for x in trial_paths)
                candidates.append((cost, agent, p, new_constraints))
        cbs_time += time.perf_counter() - t0

        if not candidates:
            fell_back = True
            break

        candidates.sort(key=lambda x: x[0])
        _, agent, p, new_constraints = candidates[0]
        paths[agent] = p
        constraints = new_constraints
        resolved_count += 1

        log.append({
            "round": round_num,
            "conflict_type": conflict["type"],
            "agent1": conflict["a1"],
            "agent2": conflict["a2"],
            "priority_score": round(score, 3),
            "model_source": model_source,
            "conflicts_seen_this_round": len(conflicts),
            "resolved_agent": agent,
        })
    else:
        fell_back = True

    if fell_back:
        t0 = time.perf_counter()
        cbs_stats = {}
        fallback_paths = run_full_cbs(grid, agents, directions=directions, stats=cbs_stats)
        cbs_time += time.perf_counter() - t0
        elapsed = time.time() - start_time
        total_expanded_nodes = round_num + cbs_stats.get("expanded_nodes", 0)
        total_replanning_count = replan_calls + cbs_stats.get("replanning_count", 0)
        if fallback_paths is None:
            timed_out = cbs_time >= CBS_MAX_SECONDS * 0.95
            reason = (
                f"Full CBS hit its {CBS_MAX_SECONDS}s time budget without finding a conflict-free "
                f"solution (instance is likely too congested - try fewer agents/obstacles, "
                f"or raise DEFAULT_MAX_SECONDS in cbs.py)."
                if timed_out else
                "Full CBS exhausted its search without finding any conflict-free solution - "
                "this instance may be genuinely unsolvable as laid out."
            )
            return None, {
                "rounds": round_num, "conflicts_resolved": resolved_count,
                "fell_back_to_cbs": True, "model_source": model_source,
                "makespan": None, "sum_of_costs": None, "log": log,
                "elapsed_seconds": elapsed,
                "lacam_time": lacam_time, "cbs_time": cbs_time, "ml_prediction_time": ml_time,
                "num_conflicts": num_conflicts, "waiting_time": None, "path_lengths": None,
                "expanded_nodes": total_expanded_nodes, "replanning_count": total_replanning_count,
                "solved": False, "failure_reason": reason,
            }
        makespan = max(len(p) for p in fallback_paths) - 1
        sum_of_costs = sum(len(p) for p in fallback_paths)
        total_wait, _ = compute_waiting_time(fallback_paths)
        return fallback_paths, {
            "rounds": round_num, "conflicts_resolved": resolved_count,
            "fell_back_to_cbs": True, "model_source": model_source,
            "makespan": makespan, "sum_of_costs": sum_of_costs, "log": log,
            "elapsed_seconds": elapsed,
            "lacam_time": lacam_time, "cbs_time": cbs_time, "ml_prediction_time": ml_time,
            "num_conflicts": num_conflicts, "waiting_time": total_wait,
            "path_lengths": compute_path_lengths(fallback_paths),
            "expanded_nodes": total_expanded_nodes, "replanning_count": total_replanning_count,
            "solved": True, "failure_reason": None,
        }

    makespan = max(len(p) for p in paths) - 1
    sum_of_costs = sum(len(p) for p in paths)
    elapsed = time.time() - start_time
    total_wait, _ = compute_waiting_time(paths)
    return paths, {
        "rounds": round_num, "conflicts_resolved": resolved_count,
        "fell_back_to_cbs": False, "model_source": model_source,
        "makespan": makespan, "sum_of_costs": sum_of_costs, "log": log,
        "elapsed_seconds": elapsed,
        "lacam_time": lacam_time, "cbs_time": cbs_time, "ml_prediction_time": ml_time,
        "num_conflicts": num_conflicts, "waiting_time": total_wait,
        "path_lengths": compute_path_lengths(paths),
        "expanded_nodes": round_num, "replanning_count": replan_calls,
        "solved": True, "failure_reason": None,
    }
