"""
Central configuration for the MAPF - CBS simulator.

Every tunable value used to be a magic number scattered across
main.py / ui.py / astar.py. They now live here, in one place, so
changing the grid size, cell size, speed, etc. doesn't require
hunting through multiple files.
"""

# --- Grid ---
GRID_ROWS = 15
GRID_COLS = 15
CELL_SIZE = 40

GRID_WIDTH = GRID_COLS * CELL_SIZE
GRID_HEIGHT = GRID_ROWS * CELL_SIZE

# --- Sidebar / window ---
SIDEBAR_WIDTH = 300
WINDOW_WIDTH = GRID_WIDTH + SIDEBAR_WIDTH
WINDOW_HEIGHT = max(GRID_HEIGHT, 520)

# --- Simulation speed ---
FPS = 8

# --- Colors (UI chrome, not agents - agents use color_utils) ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (210, 210, 210)
YELLOW = (255, 255, 0)
LIGHT_BLUE = (225, 235, 250)
RED = (220, 60, 60)

# --- A* search bound ---
# Old code used a fixed MAX_TIME = 200 regardless of grid size or how
# many agents/obstacles were present, which could cut off valid paths
# on a larger grid, or waste time on a tiny one. Instead we derive a
# bound from the grid's own dimensions: the longest an optimal path
# could ever need to be is bounded by the number of cells, so we give
# a generous multiple of that as headroom for detours around
# obstacles/constraints.
def max_search_time(rows=GRID_ROWS, cols=GRID_COLS):
    return (rows * cols) * 2


# --- LaCAM search bound ---
# LaCAM explores a tree of *joint configurations* (one node per timestep
# for the whole team), which can grow large before it either reaches the
# goal or gets stuck (e.g. rotational deadlocks that plain PIBT can't
# resolve). This caps how many high-level nodes we're willing to expand
# before giving up and falling back to CBS, which is slower per-agent
# but always finds a solution if one exists.
LACAM_MAX_ITERATIONS = 5000

