"""
Conflict detection for the hybrid ML-CBS pipeline.

cbs.py's own detect() stops at the *first* conflict it finds, which is
all plain CBS needs (it only ever resolves one conflict per search
node anyway). The hybrid pipeline is different: at every round it wants
to see *every* conflict that exists at the earliest conflicting
timestep, score each one with the Random Forest, and only then decide
which single conflict to resolve. detect_all_conflicts() below provides
that list.
"""


def detect_all_conflicts(paths):
    """Return every vertex/edge conflict that occurs at the *earliest*
    timestep where at least one conflict exists (a full CBS-style
    multi-conflict scan of that timestep). Returns [] if paths are
    already conflict-free.

    Each conflict is a dict:
      vertex: {"type": "vertex", "a1", "a2", "cell", "time"}
      edge:   {"type": "edge",   "a1", "a2", "time",
               "from1", "to1", "from2", "to2"}
    """
    if not paths:
        return []

    maxlen = max(len(p) for p in paths)
    n = len(paths)

    for t in range(maxlen):
        found = []

        # Vertex conflicts: two+ agents occupying the same cell at time t.
        occupied = {}
        for i, p in enumerate(paths):
            pos = p[min(t, len(p) - 1)]
            if pos in occupied:
                for other in occupied[pos]:
                    found.append(
                        {"type": "vertex", "a1": other, "a2": i, "cell": pos, "time": t}
                    )
                occupied[pos].append(i)
            else:
                occupied[pos] = [i]

        # Edge conflicts: two agents swapping places across the t-1 -> t step.
        if t > 0:
            for i in range(n):
                for j in range(i + 1, n):
                    p1, p2 = paths[i], paths[j]
                    a1 = p1[min(t - 1, len(p1) - 1)]
                    a2 = p1[min(t, len(p1) - 1)]
                    b1 = p2[min(t - 1, len(p2) - 1)]
                    b2 = p2[min(t, len(p2) - 1)]
                    if a1 == b2 and b1 == a2 and a1 != a2:
                        found.append(
                            {
                                "type": "edge",
                                "a1": i,
                                "a2": j,
                                "time": t,
                                "from1": a1,
                                "to1": a2,
                                "from2": b1,
                                "to2": b2,
                            }
                        )

        if found:
            return found

    return []


def make_constraint(agent, conflict):
    """Turn a conflict into the single constraint that keeps `agent`
    (whichever side of the conflict it is) out of the colliding
    cell/edge at that timestep - same constraint shape astar.py expects."""
    if conflict["type"] == "vertex":
        return {"agent": agent, "type": "vertex", "cell": conflict["cell"], "time": conflict["time"]}

    if agent == conflict["a1"]:
        frm, to = conflict["from1"], conflict["to1"]
    else:
        frm, to = conflict["from2"], conflict["to2"]
    return {"agent": agent, "type": "edge", "from": frm, "to": to, "time": conflict["time"]}
