"""
Performance Evaluation report - a separate matplotlib window that lays
out every metric the simulator tracks:

  Runtime, Makespan, Sum of Costs, Number of Conflicts, Waiting Time,
  Path Length (per agent), CBS Execution Time, LaCAM Execution Time,
  ML Prediction Time

as a summary table plus two comparison charts, instead of squeezing
them into the pygame sidebar. Built from the same `analysis` dict
main.py already threads through to ui.draw_performance_analysis() -
see hybrid_solver.py / lacam.py / metrics.py for where each field
comes from.

Opened on demand (key P) rather than imported eagerly, so the normal
simulator loop doesn't pay matplotlib's import/startup cost unless a
report is actually requested. plt.show() blocks until the report
window is closed, then control returns to the pygame loop - a report
is a one-shot, user-requested action, not something that needs to run
concurrently with the simulation.
"""

import matplotlib.pyplot as plt


def _fmt(value, suffix=""):
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:.3f}{suffix}"
    return f"{value}{suffix}"


def show_performance_report(analysis, solver_used):
    """Render and display the report. No-op if there's nothing to show
    yet (no solve has been run this session)."""
    if analysis is None:
        return

    solved = analysis.get("solved", True)  # default True for older/partial analysis dicts

    fig = plt.figure(figsize=(11, 7.2 if not solved else 6.5))
    try:
        fig.canvas.manager.set_window_title("Performance Evaluation")
    except Exception:
        pass  # backend without a window manager (e.g. headless) - fine, just skip the title
    title = f"Performance Evaluation - {solver_used or 'run'}"
    fig.suptitle(title, y=0.975, fontsize=13, fontweight="bold", color=("#B02020" if not solved else "black"))

    if not solved:
        # A failed run still has real, useful timing data (e.g. "CBS burned
        # 15s before giving up") - keep the table and time chart, but make
        # the failure impossible to miss instead of scattering silent "n/a"s
        # next to a chart that looks like everything went fine.
        # Wrapped manually (rather than relying on matplotlib's wrap=True,
        # which measures in display pixels and was overrunning into the
        # title/table above it) and given its own clear vertical band
        # below the title, separate from the gridspec below.
        import textwrap
        msg = "NO SOLUTION FOUND \u2014 " + (
            analysis.get("failure_reason") or "the solver could not produce a conflict-free path set."
        )
        wrapped_msg = "\n".join(textwrap.wrap(msg, width=95))
        fig.text(
            0.5, 0.905,
            wrapped_msg,
            ha="center", va="top", fontsize=10, color="#B02020", fontweight="bold",
        )

    top_margin = 0.80 if not solved else 0.90
    gs = fig.add_gridspec(
        2, 2, height_ratios=[1, 1.2], width_ratios=[1, 1],
        hspace=0.55, wspace=0.3, top=top_margin, bottom=0.08,
    )

    # --- Summary table (top-left) ---
    ax_table = fig.add_subplot(gs[0, 0])
    ax_table.axis("off")
    ax_table.set_title("Summary", fontsize=11, loc="left")
    rows = [
        ["Runtime", _fmt(analysis.get("elapsed_seconds"), "s")],
        ["Makespan", _fmt(analysis.get("makespan"))],
        ["Sum of Costs", _fmt(analysis.get("sum_of_costs"))],
        ["Number of Conflicts", _fmt(analysis.get("num_conflicts"))],
        ["Waiting Time", _fmt(analysis.get("waiting_time"))],
        ["Expanded Nodes", _fmt(analysis.get("expanded_nodes"))],
        ["Replanning Count", _fmt(analysis.get("replanning_count"))],
        ["Memory Usage", _fmt(analysis.get("memory_kb"), " KB")],
        ["CBS Execution Time", _fmt(analysis.get("cbs_time"), "s")],
        ["LaCAM Execution Time", _fmt(analysis.get("lacam_time"), "s")],
        ["ML Prediction Time", _fmt(analysis.get("ml_prediction_time"), "s")],
    ]
    table = ax_table.table(cellText=rows, colLabels=["Metric", "Value"], cellLoc="left", loc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(9.5)
    table.scale(1, 1.5)

    # --- Execution time breakdown (top-right) ---
    ax_time = fig.add_subplot(gs[0, 1])
    ax_time.set_title("Execution Time Breakdown", fontsize=11, loc="left")
    labels = ["LaCAM", "CBS", "ML Prediction"]
    values = [
        analysis.get("lacam_time") or 0.0,
        analysis.get("cbs_time") or 0.0,
        analysis.get("ml_prediction_time") or 0.0,
    ]
    if any(values):
        bars = ax_time.bar(labels, values, color=["#4C72B0", "#DD8452", "#55A868"])
        for b, v in zip(bars, values):
            ax_time.text(b.get_x() + b.get_width() / 2, v, f"{v:.3f}s", ha="center", va="bottom", fontsize=9)
        ax_time.set_ylabel("Seconds")
    else:
        ax_time.text(0.5, 0.5, "No timing data", ha="center", va="center", transform=ax_time.transAxes)
        ax_time.set_xticks([])
        ax_time.set_yticks([])

    # --- Path length per agent (bottom, full width) ---
    ax_paths = fig.add_subplot(gs[1, :])
    ax_paths.set_title("Path Length per Agent", fontsize=11, loc="left")
    lengths = analysis.get("path_lengths")
    if lengths:
        agent_ids = [f"A{i + 1}" for i in range(len(lengths))]
        bars = ax_paths.bar(agent_ids, lengths, color="#8172B2")
        for b, v in zip(bars, lengths):
            ax_paths.text(b.get_x() + b.get_width() / 2, v, str(v), ha="center", va="bottom", fontsize=9)
        avg = sum(lengths) / len(lengths)
        ax_paths.axhline(avg, color="#C44E52", linestyle="--", linewidth=1, label=f"Average ({avg:.1f})")
        ax_paths.legend(loc="upper right", fontsize=9)
        ax_paths.set_ylabel("Path length (cells)")
    elif not solved:
        msg = (
            "No paths to show - the run above did not find a solution.\n"
            "Try fewer agents/obstacles, or increase cbs.py's DEFAULT_MAX_SECONDS "
            "if it timed out (see the failure message above)."
        )
        ax_paths.text(0.5, 0.5, msg, ha="center", va="center", transform=ax_paths.transAxes, fontsize=9.5)
        ax_paths.set_xticks([])
        ax_paths.set_yticks([])
    else:
        ax_paths.text(0.5, 0.5, "No path data", ha="center", va="center", transform=ax_paths.transAxes)
        ax_paths.set_xticks([])
        ax_paths.set_yticks([])

    plt.show()
