"""
Trains the Random Forest that powers Conflict Priority Prediction.

Usage:
    python generate_dataset.py   # writes conflict_training_data.csv
    python train_model.py        # reads it, trains, writes rf_priority_model.joblib

The saved bundle is a dict: {"model": <RandomForestRegressor>, "feature_names": [...]}
so ml_priority.py can validate feature order at load time.
"""

import csv

import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

from feature_extraction import FEATURE_NAMES

DATASET_CSV = "conflict_training_data.csv"
MODEL_PATH = "rf_priority_model.joblib"


def load_dataset(path=DATASET_CSV):
    X, y = [], []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            X.append([float(row[name]) for name in FEATURE_NAMES])
            y.append(float(row["priority_label"]))
    return X, y


def main():
    X, y = load_dataset()
    print(f"Loaded {len(X)} training examples from {DATASET_CSV}")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(
        n_estimators=200,
        max_depth=None,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    print(f"Test MAE: {mae:.4f}   Test R^2: {r2:.4f}")

    importances = sorted(zip(FEATURE_NAMES, model.feature_importances_), key=lambda x: -x[1])
    print("Feature importances:")
    for name, imp in importances:
        print(f"  {name:22s} {imp:.4f}")

    joblib.dump({"model": model, "feature_names": FEATURE_NAMES}, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")


if __name__ == "__main__":
    main()
