"""
PIBT - Priority Inheritance with Backtracking.

This is the "low level" of LaCAM. Where CBS's low level plans one
agent's *entire path* with A*, PIBT plans one *timestep* for *every*
agent at once:

  1. Agents are sorted by priority (whoever has been waiting/stuck
     the longest goes first - this guarantees no agent starves).
  2. Each agent, in priority order, greedily picks the neighboring
     cell that gets it closest to its goal (using the BFS distance
     table), preferring to move over standing still.
  3. If that cell is already occupied by a lower-priority agent that
     hasn't moved yet, the mover "inherits priority" to that agent
     and recursively asks it to get out of the way first - hence the
     name. If the chain of pushes closes back on itself (a rotation,
     e.g. 4 agents going around a 2x2 block), the rotation is allowed
     to complete as a group.
  4. If an agent has nowhere valid to go, this whole PIBT call fails
     for that timestep - LaCAM will then backtrack and try a
     different configuration.

PIBT is fast (no full replanning), but it's a greedy, single-pass
heuristic with no lookahead, so it can still livelock in some
adjacent-swap / rotational scenarios it can't untangle. That's
expected and is why LaCAM (the caller) backtracks on failure, and
why we fall back to CBS entirely if LaCAM can't make progress at all.
"""


def _neighbors_and_stay(cell, grid):
    r, c = cell
    rows = len(grid)
    cols = len(grid[0]) if rows else 0

    options = [cell]  # staying in place is always a candidate
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
            options.append((nr, nc))
    return options


def _occupant(config, cell):
    for agent, pos in enumerate(config):
        if pos == cell:
            return agent
    return None


def _causes_swap(agent, target, config, next_config):
    """True if some already-assigned agent k is moving from `target`
    into `agent`'s current cell - i.e. the two would pass through each
    other on the same edge, which isn't a physically valid move."""
    for k, nk in next_config.items():
        if config[k] == target and nk == config[agent]:
            return True
    return False


def _pibt_step(agent, config, next_config, reserved, grid, goals, dist_tables, chain):
    chain.append(agent)

    table = dist_tables[goals[agent]]
    candidates = _neighbors_and_stay(config[agent], grid)
    candidates.sort(key=lambda cell: table.get(cell, float("inf")))

    for cell in candidates:
        if cell in reserved and reserved[cell] != agent:
            continue

        if _causes_swap(agent, cell, config, next_config):
            continue

        occupant = _occupant(config, cell)

        if occupant is None or occupant == agent:
            next_config[agent] = cell
            reserved[cell] = agent
            return True

        if occupant in chain:
            # Only allow this if it closes the chain into a rotation
            # (the occupant is the very first agent that started the
            # push chain) - otherwise it's a re-visit that would recurse
            # forever, so treat it as blocked.
            if occupant == chain[0] and len(chain) >= 2:
                next_config[agent] = cell
                reserved[cell] = agent
                return True
            continue

        if occupant in next_config:
            # occupant already committed elsewhere this step and it's
            # not this cell, so this cell is actually free of them now
            continue

        # Ask the occupant to move out of the way first (priority inheritance)
        if _pibt_step(occupant, config, next_config, reserved, grid, goals, dist_tables, chain):
            if _causes_swap(agent, cell, config, next_config):
                continue
            next_config[agent] = cell
            reserved[cell] = agent
            return True

    chain.pop()
    return False


def pibt_timestep(config, priorities, grid, goals, dist_tables):
    """
    Attempt one synchronized timestep for every agent.
    Returns a new config (tuple of positions) on success, or None if
    some agent got completely stuck.
    """
    order = sorted(range(len(config)), key=lambda i: -priorities[i])

    next_config = {}
    reserved = {}

    for agent in order:
        if agent in next_config:
            continue
        if not _pibt_step(agent, config, next_config, reserved, grid, goals, dist_tables, []):
            return None

    return tuple(next_config[i] for i in range(len(config)))
