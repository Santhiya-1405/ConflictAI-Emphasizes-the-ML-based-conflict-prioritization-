import pygame

from config import (
    GRID_ROWS,
    GRID_COLS,
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    SIDEBAR_WIDTH,
    WHITE,
    BLACK,
    GRAY,
    YELLOW,
    LIGHT_BLUE,
    RED,
)
from color_utils import generate_color
from conflict_detection import detect_conflicts_at_frame

pygame.font.init()

title_font = pygame.font.SysFont(None, 30)
font = pygame.font.SysFont(None, 24)
small_font = pygame.font.SysFont(None, 20)


def draw_grid(screen, grid):
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            rect = pygame.Rect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            if grid[r][c]:
                pygame.draw.rect(screen, BLACK, rect)
            pygame.draw.rect(screen, GRAY, rect, 1)


def get_live_conflicts(agents, animating, frame):
    """While animating, check the current frame for a collision between
    any two agents' paths and return the conflict list (see
    conflict_detection.detect_conflicts_at_frame). Empty outside of
    animation or when nothing collides right now."""
    if not animating:
        return []
    paths = [a["path"] for a in agents if "path" in a]
    if len(paths) < 2:
        return []
    return detect_conflicts_at_frame(paths, frame)


def draw_agents(screen, agents, animating, frame, live_conflicts=None):
    live_conflicts = live_conflicts or []
    conflict_cells = set()
    for c in live_conflicts:
        if c["type"] == "vertex":
            conflict_cells.add(c["cell"])
        else:
            conflict_cells.add(c["to1"])
            conflict_cells.add(c["to2"])

    for cell in conflict_cells:
        r, c = cell
        rect = pygame.Rect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE)
        pygame.draw.rect(screen, RED, rect, 4)

    for i, agent in enumerate(agents):
        color = generate_color(i)

        sr, sc = agent["start"]
        gr, gc = agent["goal"]

        pygame.draw.circle(
            screen, color,
            (sc * CELL_SIZE + CELL_SIZE // 2, sr * CELL_SIZE + CELL_SIZE // 2),
            12,
        )
        pygame.draw.rect(
            screen, color,
            (
                gc * CELL_SIZE + CELL_SIZE // 4,
                gr * CELL_SIZE + CELL_SIZE // 4,
                CELL_SIZE // 2,
                CELL_SIZE // 2,
            ),
        )

        if "path" in agent:
            for r, c in agent["path"]:
                pygame.draw.circle(
                    screen, color,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    4,
                )

            if animating:
                idx = min(frame, len(agent["path"]) - 1)
                r, c = agent["path"][idx]
                pygame.draw.circle(
                    screen, YELLOW,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    16,
                )
                pygame.draw.circle(
                    screen, color,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    12,
                )


def wrap_text(text, render_font, max_width):
    """Split text into lines that each fit within max_width when
    rendered in render_font, breaking on word boundaries. Falls back to
    returning the text as a single (overflowing) line if it has no
    spaces to break on."""
    words = text.split(" ")
    lines, line = [], ""
    for w in words:
        trial = (line + " " + w).strip()
        if render_font.size(trial)[0] > max_width and line:
            lines.append(line)
            line = w
        else:
            line = trial
    if line:
        lines.append(line)
    return lines or [text]


def draw_sidebar_controls(screen, mode, agents, solver_used):
    x = GRID_WIDTH + 20
    y = 30
    max_width = SIDEBAR_WIDTH - 40

    screen.blit(title_font.render("MAPF - LaCAM", True, BLACK), (x, y))
    y += 50

    info = [
        "1 : Obstacle mode",
        "2 : New Agent",
        "3 : Run LaCAM",
        "4 : Animate",
        "5 : Run Hybrid ML-CBS",
        "G : Toggle graph",
        "P : Performance Report",
        "B : Benchmark Report",
        "R : Reset",
        "",
        f"Mode : {mode}",
        f"Agents : {len(agents)}",
    ]
    if solver_used:
        info.append(f"Solver  : {solver_used}")

    for text in info:
        color = RED if text.startswith("Solver") and "fallback" in text else BLACK
        for line in wrap_text(text, font, max_width):
            screen.blit(font.render(line, True, color), (x, y))
            y += 30

    return y + 10


def draw_status(screen, status_message, y):
    x0 = GRID_WIDTH + 20
    width = SIDEBAR_WIDTH - 40

    box = pygame.Rect(x0, y, width, 44)
    pygame.draw.rect(screen, LIGHT_BLUE, box)
    pygame.draw.rect(screen, BLACK, box, 1)

    words = status_message.split(" ")
    lines, line = [], ""
    for w in words:
        trial = (line + " " + w).strip()
        if small_font.size(trial)[0] > width - 12 and line:
            lines.append(line)
            line = w
        else:
            line = trial
    if line:
        lines.append(line)

    ty = y + 6
    for line in lines[:3]:
        screen.blit(small_font.render(line, True, BLACK), (x0 + 6, ty))
        ty += 18

    return y + 44 + 10


def draw_stats_chart(screen, agents, start_y):
    """Bar chart of each agent's path length, same as the CBS version -
    lets you visually compare solution quality regardless of which
    solver (LaCAM or CBS fallback) produced it."""
    x0 = GRID_WIDTH + 20
    panel_width = SIDEBAR_WIDTH - 40
    panel_height = GRID_HEIGHT - start_y - 20

    if panel_height < 40:
        return

    panel_rect = pygame.Rect(x0, start_y, panel_width, panel_height)
    pygame.draw.rect(screen, LIGHT_BLUE, panel_rect)
    pygame.draw.rect(screen, BLACK, panel_rect, 1)

    screen.blit(small_font.render("Path length per agent", True, BLACK), (x0 + 8, start_y + 6))

    solved = [(i, a) for i, a in enumerate(agents) if "path" in a]
    if not solved:
        screen.blit(small_font.render("(run LaCAM to see results)", True, BLACK), (x0 + 8, start_y + 30))
        return

    lengths = [len(a["path"]) for _, a in solved]
    max_len = max(lengths) if lengths else 1
    makespan = max_len - 1 if max_len else 0

    chart_top = start_y + 30
    chart_bottom = start_y + panel_height - 25
    chart_height = max(chart_bottom - chart_top, 10)

    bar_area_width = panel_width - 16
    bar_gap = 6
    bar_width = max((bar_area_width - bar_gap * len(solved)) // max(len(solved), 1), 4)

    bx = x0 + 8
    for i, a in solved:
        length = len(a["path"])
        bar_height = int((length / max_len) * chart_height) if max_len else 0
        color = generate_color(i)

        bar_rect = pygame.Rect(bx, chart_bottom - bar_height, bar_width, bar_height)
        pygame.draw.rect(screen, color, bar_rect)
        pygame.draw.rect(screen, BLACK, bar_rect, 1)

        label = small_font.render(str(length), True, BLACK)
        screen.blit(label, (bx, chart_bottom - bar_height - 18))

        bx += bar_width + bar_gap

    pygame.draw.line(screen, BLACK, (x0 + 8, chart_bottom), (x0 + panel_width - 8, chart_bottom), 2)
    summary = f"Makespan: {makespan}   Cost: {sum(lengths)}"
    screen.blit(small_font.render(summary, True, RED), (x0 + 8, chart_bottom + 5))



def draw_conflict_banner(screen, live_conflicts, start_y):
    """Real-time banner: exact (row, col) cell and time step for every
    collision happening at the current animation frame. Only rendered
    while a conflict is actually occurring."""
    if not live_conflicts:
        return start_y

    x0 = GRID_WIDTH + 20
    width = SIDEBAR_WIDTH - 40

    lines = ["Conflict detected!"]
    for c in live_conflicts:
        if c["type"] == "vertex":
            r, col = c["cell"]
            lines.append(f"Agents {c['a1']+1} & {c['a2']+1} at ({col}, {r}), t={c['time']}")
        else:
            r, col = c["to1"]
            lines.append(f"Agents {c['a1']+1} & {c['a2']+1} swap at ({col}, {r}), t={c['time']}")

    wrapped = []
    for text in lines:
        wrapped.extend(wrap_text(text, small_font, width - 12))

    box_height = 20 * len(wrapped) + 12
    box = pygame.Rect(x0, start_y, width, box_height)
    pygame.draw.rect(screen, RED, box)
    pygame.draw.rect(screen, BLACK, box, 1)

    y = start_y + 6
    for text in wrapped:
        screen.blit(small_font.render(text, True, WHITE), (x0 + 6, y))
        y += 20

    return start_y + box_height + 10


def draw_screen(screen, grid, agents, mode, animating, frame, show_stats=True, status_message="", solver_used="", analysis=None):
    screen.fill(WHITE)

    live_conflicts = get_live_conflicts(agents, animating, frame)

    draw_grid(screen, grid)
    draw_agents(screen, agents, animating, frame, live_conflicts)

    next_y = draw_sidebar_controls(screen, mode, agents, solver_used)

    if status_message:
        next_y = draw_status(screen, status_message, next_y)

    next_y = draw_conflict_banner(screen, live_conflicts, next_y)

    if show_stats:
        draw_stats_chart(screen, agents, next_y)

    pygame.display.update()
