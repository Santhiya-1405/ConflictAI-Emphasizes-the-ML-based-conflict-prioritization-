"""
Builds the training dataset for the Random Forest conflict-priority model.

Ground truth for "which conflict should be resolved first" would ideally
come from exhaustively searching every possible CBS branching order and
measuring which choice led to the smallest search tree - but that's
factorially expensive and impractical to generate at scale. Instead we
label each conflict with heuristic_priority_score() (ml_priority.py): a
transparent, hand-designed scoring formula grounded in the same signals
CBS-tuning literature already uses (edge conflicts are worse than vertex
conflicts, congestion/obstacle density nearby predicts cascading
conflicts, earlier timesteps are more urgent than later ones), plus a
touch of Gaussian noise so the model learns a smooth, generalizable
function of the 10 features instead of memorizing the formula exactly.

Run this, then train_model.py, whenever you want to regenerate/retrain
the model (e.g. after changing the feature set or the heuristic).
"""

import csv
import random

from astar import astar
from conflict_detection import detect_all_conflicts
from feature_extraction import FEATURE_NAMES, extract_conflict_features
from ml_priority import heuristic_priority_score

OUTPUT_CSV = "conflict_training_data.csv"
NUM_SCENARIOS = 400
NOISE_STD = 0.4


def random_grid(rows, cols, obstacle_prob):
    return [[1 if random.random() < obstacle_prob else 0 for _ in range(cols)] for _ in range(rows)]


def random_free_cell(grid, taken):
    rows, cols = len(grid), len(grid[0])
    for _ in range(200):
        r, c = random.randrange(rows), random.randrange(cols)
        if grid[r][c] == 0 and (r, c) not in taken:
            return (r, c)
    return None


def random_scenario():
    rows = random.randint(8, 16)
    cols = random.randint(8, 16)
    obstacle_prob = random.uniform(0.05, 0.2)
    n_agents = random.randint(3, 10)

    grid = random_grid(rows, cols, obstacle_prob)

    agents = []
    taken = set()
    for _ in range(n_agents):
        start = random_free_cell(grid, taken)
        if start is None:
            break
        taken.add(start)
        goal = random_free_cell(grid, taken)
        if goal is None:
            taken.discard(start)
            break
        taken.add(goal)
        agents.append({"start": start, "goal": goal})

    return grid, agents


def independent_paths(grid, agents):
    """Each agent's own shortest path, ignoring every other agent - a
    fast, conflict-oblivious initial guess (the 'Initial Paths' stage
    of the pipeline). Deliberately prone to conflicts, which is exactly
    what we need training examples of."""
    paths = []
    for i, a in enumerate(agents):
        p = astar(grid, i, a["start"], a["goal"], [])
        if p is None:
            return None
        paths.append(p)
    return paths


def build_dataset():
    rows_out = []
    scenarios_used = 0
    attempts = 0

    while scenarios_used < NUM_SCENARIOS and attempts < NUM_SCENARIOS * 4:
        attempts += 1
        grid, agents = random_scenario()
        if len(agents) < 2:
            continue

        paths = independent_paths(grid, agents)
        if paths is None:
            continue

        conflicts = detect_all_conflicts(paths)
        if not conflicts:
            continue

        scenarios_used += 1
        for conflict in conflicts:
            feats = extract_conflict_features(conflict, paths, grid)
            label = heuristic_priority_score(feats) + random.gauss(0, NOISE_STD)
            row = dict(feats)
            row["priority_label"] = label
            rows_out.append(row)

    return rows_out


def main():
    random.seed(42)
    rows_out = build_dataset()

    with open(OUTPUT_CSV, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FEATURE_NAMES + ["priority_label"])
        writer.writeheader()
        writer.writerows(rows_out)

    print(f"Wrote {len(rows_out)} conflict examples to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
