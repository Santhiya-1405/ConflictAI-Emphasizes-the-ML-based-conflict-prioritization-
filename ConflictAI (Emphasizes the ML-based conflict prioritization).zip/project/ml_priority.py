"""
Conflict priority prediction.

This is the "Random Forest -> Conflict Priority Prediction" stage of the
pipeline:

    Conflict Detection -> Feature Extraction -> Random Forest
        -> Conflict Priority Prediction -> CBS Conflict Resolution

Given the 10 features for a conflict (feature_extraction.py), predict a
single priority score. Higher score = more urgent = resolve this
conflict before the others detect_all_conflicts() found at this round.

If a trained model file (rf_priority_model.joblib) is present, it is
used. If not (e.g. train_model.py hasn't been run yet), we fall back to
the same hand-crafted scoring formula used to *label* the training data
in generate_dataset.py, so the simulator still works out of the box -
it just isn't using the learned model yet.
"""

import os

from feature_extraction import FEATURE_NAMES, features_to_vector

MODEL_PATH = os.path.join(os.path.dirname(__file__), "rf_priority_model.joblib")

_model_cache = {"loaded": False, "model": None}


def heuristic_priority_score(features):
    """Hand-crafted proxy for 'how urgent is this conflict'. Used both
    as the training label in generate_dataset.py and as a dependency
    -free fallback here. Higher => resolve sooner.

    Rationale:
      - edge (swap) conflicts are generally harder to route around than
        a simple vertex overlap, so they start with a higher base score.
      - more nearby agents/obstacles means fewer detour options at that
        spot, so a conflict there is more likely to cascade if left.
      - conflicts happening soon (small timestep) are more urgent than
        ones far in the future, which may resolve themselves once
        earlier constraints are added.
      - a mild congestion-pressure term (cost relative to makespan).
    """
    base = 2.0 if features["conflict_type"] == 1 else 1.0
    score = (
        base
        + features["nearby_agents"] * 1.5
        + features["nearby_obstacles"] * 1.0
        - features["conflict_timestep"] * 0.05
        + (features["current_sum_of_costs"] / max(1, features["current_makespan"] + 1)) * 0.1
    )
    return score


def load_model():
    """Load the trained RandomForestRegressor once and cache it. Returns
    None if no trained model file is available (caller should fall back
    to heuristic_priority_score)."""
    if _model_cache["loaded"]:
        return _model_cache["model"]

    _model_cache["loaded"] = True
    if os.path.exists(MODEL_PATH):
        try:
            import joblib

            bundle = joblib.load(MODEL_PATH)
            _model_cache["model"] = bundle
        except Exception:
            _model_cache["model"] = None
    return _model_cache["model"]


def predict_priority(features):
    """Return (score, source) where source is 'rf' or 'heuristic'."""
    bundle = load_model()
    if bundle is not None:
        model = bundle["model"]
        vector = [features_to_vector(features)]
        score = float(model.predict(vector)[0])
        return score, "rf"
    return heuristic_priority_score(features), "heuristic"


def select_priority_conflict(conflicts, paths, grid):
    """Score every candidate conflict and return the highest-priority one.

    Returns (best_conflict, best_features, best_score, source, all_scored)
    where all_scored is a list of (score, conflict, features) for every
    candidate, sorted highest-priority first - handy for UI/debugging.
    """
    from feature_extraction import extract_conflict_features

    scored = []
    source = "heuristic"
    for c in conflicts:
        feats = extract_conflict_features(c, paths, grid)
        score, source = predict_priority(feats)
        scored.append((score, c, feats))

    scored.sort(key=lambda x: -x[0])
    best_score, best_conflict, best_features = scored[0]
    return best_conflict, best_features, best_score, source, scored
