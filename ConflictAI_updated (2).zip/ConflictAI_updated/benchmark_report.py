"""
Benchmark report - generates the six standard MAPF evaluation graphs
FROM ACTUAL SOLVER RUNS, instead of pasting in static picture files:

  1. Runtime vs Number of Agents
  2. Makespan vs Number of Agents
  3. Sum of Cost vs Number of Agents
  4. Number of Conflicts vs Number of Agents
  5. CBS vs LaCAM Runtime Comparison
  6. Average Waiting Time per Agent vs Number of Agents

How it works
------------
run_benchmark() sweeps a range of agent counts. For each count it drops
`trials` random start/goal scenarios onto the *current* grid (so it
respects whatever obstacles you've drawn), solves each scenario with
plain CBS and with plain LaCAM (both timed independently, each with
its own 4-direction -> 8-direction diagonal fallback, mirroring the
same policy lacam.solve() uses), and records the metrics. Results are
averaged across the trials that actually solved, per agent count.

show_benchmark_report() then takes those numbers and draws a live
6-panel matplotlib figure - the data is real search output, so re-run
it after changing the grid/obstacles and the graphs change too.

Opened on demand (key B in main.py) - same lazy-import-of-matplotlib
pattern as performance_report.py, so the normal simulator loop doesn't
pay for it unless a benchmark is actually requested.
"""

import random
import time

import matplotlib.pyplot as plt

from config import DIRECTIONS_4, DIRECTIONS_8
from cbs import cbs as run_cbs
from lacam import solve_lacam
from metrics import count_initial_conflicts, waiting_time

DEFAULT_AGENT_COUNTS = (2, 4, 6, 8, 10)
DEFAULT_TRIALS = 3
DEFAULT_MAX_SECONDS = 5      # per CBS attempt - kept short, this runs many times over
DEFAULT_MAX_ITERATIONS = 2000  # per LaCAM attempt


def _random_free_cell(grid, taken, rng):
    rows, cols = len(grid), len(grid[0])
    for _ in range(300):
        r, c = rng.randrange(rows), rng.randrange(cols)
        if grid[r][c] == 0 and (r, c) not in taken:
            return (r, c)
    return None


def _random_scenario(grid, n_agents, rng):
    """Place n_agents non-overlapping start/goal pairs on the grid's
    free cells. Returns the agent list, or None if the grid doesn't
    have room for that many agents."""
    agents = []
    taken = set()
    for _ in range(n_agents):
        start = _random_free_cell(grid, taken, rng)
        if start is None:
            return None
        taken.add(start)
        goal = _random_free_cell(grid, taken, rng)
        if goal is None:
            return None
        taken.add(goal)
        agents.append({"start": start, "goal": goal})
    return agents


def _solve_cbs(grid, agents, max_seconds):
    t0 = time.perf_counter()
    paths = run_cbs(grid, agents, max_seconds=max_seconds, directions=DIRECTIONS_4)
    elapsed = time.perf_counter() - t0
    if paths is not None:
        return paths, elapsed
    t0 = time.perf_counter()
    paths = run_cbs(grid, agents, max_seconds=max_seconds, directions=DIRECTIONS_8)
    elapsed += time.perf_counter() - t0
    return paths, elapsed


def _solve_lacam(grid, agents, max_iterations):
    t0 = time.perf_counter()
    paths = solve_lacam(grid, agents, max_iterations=max_iterations, directions=DIRECTIONS_4)
    elapsed = time.perf_counter() - t0
    if paths is not None:
        return paths, elapsed
    t0 = time.perf_counter()
    paths = solve_lacam(grid, agents, max_iterations=max_iterations, directions=DIRECTIONS_8)
    elapsed += time.perf_counter() - t0
    return paths, elapsed


def run_benchmark(
    grid,
    agent_counts=DEFAULT_AGENT_COUNTS,
    trials=DEFAULT_TRIALS,
    max_seconds=DEFAULT_MAX_SECONDS,
    max_iterations=DEFAULT_MAX_ITERATIONS,
    seed=42,
    progress_callback=None,
):
    """Sweep agent_counts, solving `trials` random scenarios per count
    with both CBS and LaCAM. Returns a dict:

        {n: {
            "cbs_runtime": avg seconds or None,
            "lacam_runtime": avg seconds or None,
            "makespan": avg or None,
            "sum_of_cost": avg or None,
            "num_conflicts": avg or None,
            "avg_wait": avg per-agent waiting steps or None,
            "solved_trials": int, "attempted_trials": int,
        }, ...}

    progress_callback(n, total_counts), if given, is called after each
    agent count finishes - lets the caller repaint a "Benchmarking..."
    status between counts instead of freezing with no feedback.
    """
    rng = random.Random(seed)
    results = {}

    for idx, n in enumerate(agent_counts):
        cbs_runtimes, lacam_runtimes = [], []
        makespans, sum_costs, conflicts_list, waits = [], [], [], []
        attempted = 0

        for _ in range(trials):
            agents = _random_scenario(grid, n, rng)
            if agents is None:
                continue
            attempted += 1

            conflicts = count_initial_conflicts(grid, agents, DIRECTIONS_4)
            if conflicts is None:
                conflicts = count_initial_conflicts(grid, agents, DIRECTIONS_8)

            cbs_paths, cbs_time = _solve_cbs(grid, agents, max_seconds)
            lacam_paths, lacam_time = _solve_lacam(grid, agents, max_iterations)

            if cbs_paths is None and lacam_paths is None:
                continue

            if cbs_paths is not None:
                cbs_runtimes.append(cbs_time)
            if lacam_paths is not None:
                lacam_runtimes.append(lacam_time)

            ref_paths = cbs_paths if cbs_paths is not None else lacam_paths
            makespans.append(max(len(p) for p in ref_paths) - 1)
            sum_costs.append(sum(len(p) for p in ref_paths))
            total_wait, _ = waiting_time(ref_paths)
            waits.append(total_wait / len(ref_paths))
            if conflicts is not None:
                conflicts_list.append(conflicts)

        def avg(values):
            return (sum(values) / len(values)) if values else None

        results[n] = {
            "cbs_runtime": avg(cbs_runtimes),
            "lacam_runtime": avg(lacam_runtimes),
            "makespan": avg(makespans),
            "sum_of_cost": avg(sum_costs),
            "num_conflicts": avg(conflicts_list),
            "avg_wait": avg(waits),
            "solved_trials": len(makespans),
            "attempted_trials": attempted,
        }

        if progress_callback is not None:
            progress_callback(idx + 1, len(agent_counts))

    return results


def _line_panel(ax, ns, series, title, ylabel, color="#4C72B0", label=None):
    xs = [n for n, v in zip(ns, series) if v is not None]
    ys = [v for v in series if v is not None]
    ax.set_title(title, fontsize=10.5, loc="left")
    ax.set_xlabel("Number of Agents")
    ax.set_ylabel(ylabel)
    if ys:
        ax.plot(xs, ys, marker="o", color=color, label=label)
        if label:
            ax.legend(fontsize=8, loc="best")
    else:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax.transAxes)
        ax.set_xticks([])
        ax.set_yticks([])


def show_benchmark_report(results):
    """Render the six-panel benchmark figure from a run_benchmark() result."""
    if not results:
        return

    ns = sorted(results.keys())
    runtime_cbs = [results[n]["cbs_runtime"] for n in ns]
    runtime_lacam = [results[n]["lacam_runtime"] for n in ns]
    makespan = [results[n]["makespan"] for n in ns]
    sum_cost = [results[n]["sum_of_cost"] for n in ns]
    conflicts = [results[n]["num_conflicts"] for n in ns]
    avg_wait = [results[n]["avg_wait"] for n in ns]

    fig = plt.figure(figsize=(13, 7.5))
    try:
        fig.canvas.manager.set_window_title("Benchmark Report")
    except Exception:
        pass
    fig.suptitle("MAPF Benchmark - metrics vs Number of Agents", y=0.975, fontsize=13, fontweight="bold")

    gs = fig.add_gridspec(2, 3, hspace=0.45, wspace=0.35, top=0.90, bottom=0.08, left=0.06, right=0.98)

    # 1. Runtime vs Number of Agents (both solvers on one chart)
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_title("Runtime vs Number of Agents", fontsize=10.5, loc="left")
    ax1.set_xlabel("Number of Agents")
    ax1.set_ylabel("Seconds")
    xs_c = [n for n, v in zip(ns, runtime_cbs) if v is not None]
    ys_c = [v for v in runtime_cbs if v is not None]
    xs_l = [n for n, v in zip(ns, runtime_lacam) if v is not None]
    ys_l = [v for v in runtime_lacam if v is not None]
    if ys_c:
        ax1.plot(xs_c, ys_c, marker="o", color="#DD8452", label="CBS")
    if ys_l:
        ax1.plot(xs_l, ys_l, marker="o", color="#4C72B0", label="LaCAM")
    if ys_c or ys_l:
        ax1.legend(fontsize=8, loc="best")
    else:
        ax1.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax1.transAxes)

    # 2. Makespan vs Number of Agents
    _line_panel(fig.add_subplot(gs[0, 1]), ns, makespan, "Makespan vs Number of Agents", "Makespan", "#55A868")

    # 3. Sum of Cost vs Number of Agents
    _line_panel(fig.add_subplot(gs[0, 2]), ns, sum_cost, "Sum of Cost vs Number of Agents", "Sum of Cost", "#8172B2")

    # 4. Number of Conflicts vs Number of Agents
    _line_panel(fig.add_subplot(gs[1, 0]), ns, conflicts, "Number of Conflicts vs Number of Agents",
                "Conflicts (initial)", "#C44E52")

    # 5. CBS vs LaCAM Runtime Comparison (grouped bars - different view from panel 1's lines)
    ax5 = fig.add_subplot(gs[1, 1])
    ax5.set_title("CBS vs LaCAM Runtime Comparison", fontsize=10.5, loc="left")
    ax5.set_xlabel("Number of Agents")
    ax5.set_ylabel("Seconds")
    width = 0.38
    x_pos = range(len(ns))
    cbs_vals = [v if v is not None else 0 for v in runtime_cbs]
    lacam_vals = [v if v is not None else 0 for v in runtime_lacam]
    if any(cbs_vals) or any(lacam_vals):
        ax5.bar([x - width / 2 for x in x_pos], cbs_vals, width, label="CBS", color="#DD8452")
        ax5.bar([x + width / 2 for x in x_pos], lacam_vals, width, label="LaCAM", color="#4C72B0")
        ax5.set_xticks(list(x_pos))
        ax5.set_xticklabels([str(n) for n in ns])
        ax5.legend(fontsize=8, loc="best")
    else:
        ax5.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax5.transAxes)

    # 6. Average Waiting Time per Agent vs Number of Agents
    _line_panel(fig.add_subplot(gs[1, 2]), ns, avg_wait, "Average Waiting Time per Agent", "Avg wait (steps)", "#937860")

    plt.show()
