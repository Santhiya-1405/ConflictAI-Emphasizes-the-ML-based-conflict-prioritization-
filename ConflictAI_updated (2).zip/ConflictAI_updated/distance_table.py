"""
Per-goal BFS distance tables.

LaCAM's low-level move-picking (PIBT) needs to know, for any cell, how
far that cell is from an agent's goal - not as the crow flies (like the
Manhattan heuristic A* uses), but the *true* shortest distance around
obstacles. That's because PIBT greedily commits to whichever neighbor
looks best right now with no backtracking at the single-step level, so
a heuristic that ignores walls can walk an agent straight into a dead
end.

We precompute one full BFS per distinct goal cell (goals repeat far
less often than the number of timesteps we'll query), and reuse it for
every agent that shares that goal and every timestep of the search.
"""

from collections import deque

from config import DIRECTIONS_4, DIRECTIONS_8, ALLOW_DIAGONAL_CORNER_CUTTING


def bfs_distances(grid, goal, directions=DIRECTIONS_4):
    """Shortest-path distance (in steps) from every reachable cell to `goal`,
    ignoring other agents - only static obstacles block movement."""
    rows = len(grid)
    cols = len(grid[0]) if rows else 0

    dist = {goal: 0}
    queue = deque([goal])

    while queue:
        r, c = queue.popleft()
        d = dist[(r, c)]

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
                if dr != 0 and dc != 0 and not ALLOW_DIAGONAL_CORNER_CUTTING:
                    if grid[r + dr][c] == 1 or grid[r][c + dc] == 1:
                        continue
                if (nr, nc) not in dist:
                    dist[(nr, nc)] = d + 1
                    queue.append((nr, nc))

    return dist


def build_distance_tables(grid, goals, directions=DIRECTIONS_4):
    """One BFS distance table per distinct goal cell."""
    tables = {}
    for goal in set(goals):
        tables[goal] = bfs_distances(grid, goal, directions)
    return tables


def find_unreachable_agent(grid, agents):
    """Return the index of the first agent whose goal can't be reached
    from its start at all (ignoring every other agent - this is a pure
    connectivity check against the static obstacles), or None if every
    agent's start/goal pair is connected.

    This checks connectivity under the *widest* movement model
    (diagonals included) since that's what every solver will have
    already fallen back to trying by the time this is called - if an
    agent still can't get home even with diagonals allowed, no solver
    can ever succeed for it, no matter how long it runs."""
    for i, a in enumerate(agents):
        reachable = bfs_distances(grid, a["goal"], DIRECTIONS_8)
        if a["start"] not in reachable:
            return i
    return None
