import heapq

from config import (
    max_search_time,
    DIRECTIONS_4,
    ALLOW_DIAGONAL_CORNER_CUTTING,
)


def heuristic(a, b, diagonal=False):

    dr = abs(a[0] - b[0])

    dc = abs(a[1] - b[1])

    if diagonal:

        # Chebyshev distance: a diagonal step covers one row and one
        # column at once, so the fewest possible moves is however many
        # of the larger axis remain - using Manhattan distance here
        # would overestimate and break A*'s optimality guarantee once
        # diagonal moves are on the table.
        return max(dr, dc)

    return dr + dc


def neighbours(node, grid, directions=DIRECTIONS_4):

    r, c = node

    rows = len(grid)

    cols = len(grid[0])

    dirs = list(directions) + [(0, 0)]

    out = []

    for dr, dc in dirs:

        nr = r + dr

        nc = c + dc

        if 0 <= nr < rows:

            if 0 <= nc < cols:

                if grid[nr][nc] == 0:

                    is_diagonal = dr != 0 and dc != 0

                    if is_diagonal and not ALLOW_DIAGONAL_CORNER_CUTTING:

                        if grid[r + dr][c] == 1 or grid[r][c + dc] == 1:

                            continue

                    out.append(

                        (nr, nc)

                    )

    return out


def violates(

    agent,

    frm,

    to,

    time,

    constraints

):

    for c in constraints:

        if c["agent"] != agent:

            continue

        if c["type"] == "vertex":

            if (

                c["time"] == time

                and

                c["cell"] == to

            ):

                return True

        if c["type"] == "edge":

            if c["time"] == time:

                if (

                    c["from"] == frm

                    and

                    c["to"] == to

                ):

                    return True

    return False


def astar(

    grid,

    agent,

    start,

    goal,

    constraints,

    directions=DIRECTIONS_4

):

    open_set = []

    heapq.heappush(

        open_set,

        (0, start, 0)

    )

    parent = {}

    g = {

        (start, 0): 0

    }

    visited = set()

    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    MAX_TIME = max_search_time(rows, cols)
    is_diagonal_model = any(dr != 0 and dc != 0 for dr, dc in directions)

    while open_set:

        _, current, time = heapq.heappop(

            open_set

        )

        state = (

            current,

            time

        )

        if state in visited:

            continue

        visited.add(state)

        if current == goal:

            path = []

            s = state

            while s in parent:

                path.append(

                    s[0]

                )

                s = parent[s]

            path.append(start)

            path.reverse()

            return path

        if time > MAX_TIME:

            continue

        for nxt in neighbours(

            current,

            grid,

            directions

        ):

            nt = time + 1

            if violates(

                agent,

                current,

                nxt,

                nt,

                constraints

            ):

                continue

            key = (

                nxt,

                nt

            )

            ng = g[state] + 1

            if (

                key not in g

                or

                ng < g[key]

            ):

                g[key] = ng

                parent[key] = state

                f = ng + heuristic(

                    nxt,

                    goal,

                    is_diagonal_model

                )

                heapq.heappush(

                    open_set,

                    (

                        f,

                        nxt,

                        nt

                    )

                )

    return None