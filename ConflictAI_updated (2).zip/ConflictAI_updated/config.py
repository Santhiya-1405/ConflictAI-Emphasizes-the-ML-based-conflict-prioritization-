"""
Central configuration for the MAPF - CBS simulator.

Every tunable value used to be a magic number scattered across
main.py / ui.py / astar.py. They now live here, in one place, so
changing the grid size, cell size, speed, etc. doesn't require
hunting through multiple files.
"""

# --- Grid ---
GRID_ROWS = 15
GRID_COLS = 15
CELL_SIZE = 40

GRID_WIDTH = GRID_COLS * CELL_SIZE
GRID_HEIGHT = GRID_ROWS * CELL_SIZE

# --- Sidebar / window ---
# 300px was too narrow once longer status strings showed up (e.g.
# "Solver : Hybrid (heuristic priority)"), so lines were getting
# clipped by the window's right edge. Widened, and draw_sidebar_controls
# now also wraps any line that's still too long for the space it has.
SIDEBAR_WIDTH = 380
WINDOW_WIDTH = GRID_WIDTH + SIDEBAR_WIDTH
WINDOW_HEIGHT = max(GRID_HEIGHT, 520)

# --- Simulation speed ---
FPS = 8

# --- Colors (UI chrome, not agents - agents use color_utils) ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (210, 210, 210)
YELLOW = (255, 255, 0)
LIGHT_BLUE = (225, 235, 250)
RED = (220, 60, 60)

# --- A* search bound ---
# Old code used a fixed MAX_TIME = 200 regardless of grid size or how
# many agents/obstacles were present, which could cut off valid paths
# on a larger grid, or waste time on a tiny one. Instead we derive a
# bound from the grid's own dimensions: the longest an optimal path
# could ever need to be is bounded by the number of cells, so we give
# a generous multiple of that as headroom for detours around
# obstacles/constraints.
def max_search_time(rows=GRID_ROWS, cols=GRID_COLS):
    return (rows * cols) * 2


# --- Movement model ---
# 4-directional (orthogonal) movement is the default for every solver -
# it's the more "physical" model for a warehouse-style grid where
# agents can't shortcut diagonally between cells. If an agent's
# start/goal can't be connected under that rule alone (obstacles block
# every orthogonal route), the solvers automatically widen the
# movement model to include the 4 diagonals and replan the whole
# instance from scratch - this can open up a route that threads
# between two diagonally-touching obstacles.
DIRECTIONS_4 = [(-1, 0), (1, 0), (0, -1), (0, 1)]
DIRECTIONS_8 = DIRECTIONS_4 + [(-1, -1), (-1, 1), (1, -1), (1, 1)]

# When moving diagonally, whether to allow "cutting the corner" through
# a pair of orthogonally-adjacent blocked cells (e.g. slipping between
# two walls that meet at a corner). This is the whole point of the
# diagonal fallback: if it's disallowed, a diagonal move is only ever
# legal when both flanking cells are already open - and in that case
# there's already an equal-or-shorter orthogonal route, so diagonal
# movement could never rescue an instance that's genuinely infeasible
# under 4-directional movement. Left on so "no 4-direction path exists"
# can actually be resolved by enabling diagonals, at the cost of
# allowing a diagonal step to graze between two touching obstacles.
ALLOW_DIAGONAL_CORNER_CUTTING = True


# --- LaCAM search bound ---
# LaCAM explores a tree of *joint configurations* (one node per timestep
# for the whole team), which can grow large before it either reaches the
# goal or gets stuck (e.g. rotational deadlocks that plain PIBT can't
# resolve). This caps how many high-level nodes we're willing to expand
# before giving up and falling back to CBS, which is slower per-agent
# but always finds a solution if one exists.
LACAM_MAX_ITERATIONS = 5000

