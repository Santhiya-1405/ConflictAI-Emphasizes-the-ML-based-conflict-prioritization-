"""
Feature extraction for the Random Forest conflict-priority model.

Every detected conflict (vertex or edge) is turned into a fixed-length
feature vector describing *where*, *when*, and *in what context* it
happens. The Random Forest (see ml_priority.py) scores this vector to
say how urgent the conflict is, so the hybrid solver knows which
conflict to resolve first instead of always picking whichever one
detect_all_conflicts() happened to find first.

The 10 features (fixed order - must match training in generate_dataset.py
and ml_priority.py):

    1. agent1_id            - Agent 1 ID
    2. agent2_id            - Agent 2 ID
    3. conflict_timestep    - Conflict Time Step
    4. conflict_x           - Conflict X Coordinate (row)
    5. conflict_y           - Conflict Y Coordinate (col)
    6. conflict_type        - Conflict Type (0 = vertex, 1 = edge)
    7. nearby_obstacles     - Number of Nearby Obstacles
    8. nearby_agents        - Number of Nearby Agents
    9. current_makespan     - Current Makespan
   10. current_sum_of_costs - Current Sum of Costs
"""

FEATURE_NAMES = [
    "agent1_id",
    "agent2_id",
    "conflict_timestep",
    "conflict_x",
    "conflict_y",
    "conflict_type",
    "nearby_obstacles",
    "nearby_agents",
    "current_makespan",
    "current_sum_of_costs",
]

NEARBY_RADIUS = 2  # Manhattan-distance radius used for both nearby counts


def _conflict_position(conflict):
    """Representative (row, col) cell for a conflict, used for locality
    features (nearby obstacles/agents)."""
    if conflict["type"] == "vertex":
        return conflict["cell"]
    # Edge conflicts don't share a single cell - use agent1's destination
    # cell as the representative location of the swap.
    return conflict["to1"]


def _count_nearby_obstacles(grid, pos, radius=NEARBY_RADIUS):
    r0, c0 = pos
    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    count = 0
    for dr in range(-radius, radius + 1):
        for dc in range(-radius, radius + 1):
            if dr == 0 and dc == 0:
                continue
            r, c = r0 + dr, c0 + dc
            if 0 <= r < rows and 0 <= c < cols and grid[r][c] == 1:
                if abs(dr) + abs(dc) <= radius:
                    count += 1
    return count


def _count_nearby_agents(paths, t, pos, exclude, radius=NEARBY_RADIUS):
    count = 0
    for i, p in enumerate(paths):
        if i in exclude:
            continue
        idx = min(t, len(p) - 1)
        r, c = p[idx]
        if abs(r - pos[0]) + abs(c - pos[1]) <= radius:
            count += 1
    return count


def extract_conflict_features(conflict, paths, grid):
    """Build the 10-feature dict for a single conflict, given the full
    current path set and the static grid."""
    pos = _conflict_position(conflict)
    t = conflict["time"]

    makespan = max((len(p) for p in paths), default=1) - 1
    sum_of_costs = sum(len(p) for p in paths)

    return {
        "agent1_id": conflict["a1"],
        "agent2_id": conflict["a2"],
        "conflict_timestep": t,
        "conflict_x": pos[0],
        "conflict_y": pos[1],
        "conflict_type": 1 if conflict["type"] == "edge" else 0,
        "nearby_obstacles": _count_nearby_obstacles(grid, pos),
        "nearby_agents": _count_nearby_agents(
            paths, t, pos, exclude={conflict["a1"], conflict["a2"]}
        ),
        "current_makespan": makespan,
        "current_sum_of_costs": sum_of_costs,
    }


def features_to_vector(features):
    """Dict -> ordered list, in the exact order the model expects."""
    return [features[name] for name in FEATURE_NAMES]
