"""
LaCAM high-level search.

CBS's high level searches over *constraint sets* (one A* re-plan per
branch). LaCAM instead searches over *joint configurations* - literally
"where is every agent right now" - one step forward in time per search
node:

  root node       = everyone at their start
  each child node = one more synchronized timestep, produced by
                    calling PIBT on the parent's configuration
  goal            = a node where every agent is standing on its goal

It's a depth-first search: keep pushing new timesteps forward via
PIBT. If PIBT can't produce a valid next step (or it produces a
configuration we've already visited on this path - a sign of a loop/
livelock), backtrack and try again with adjusted priorities.

`priorities` carries forward: any agent not on its goal yet has its
priority increased each step, so an agent that's been stuck the
longest always gets to move first the next time PIBT runs. This is
what prevents PIBT from repeatedly starving the same agent.

If LaCAM exhausts its iteration budget without finding a solution
(the known failure mode: rotational/adjacent-swap deadlocks PIBT
can't untangle on its own), we fall back to CBS, which is slower but
complete - it will always find a solution if one exists.
"""

import time

from config import LACAM_MAX_ITERATIONS, max_search_time, DIRECTIONS_4, DIRECTIONS_8
from distance_table import build_distance_tables
from pibt import pibt_timestep
from cbs import cbs as run_cbs


def _reconstruct(parent, node, agent_count):
    chain = []
    cur = node
    while cur is not None:
        chain.append(cur[0])  # cur = (config, parent_key, priorities)
        cur = parent.get(cur)
    chain.reverse()

    paths = [[] for _ in range(agent_count)]
    for config in chain:
        for i, pos in enumerate(config):
            paths[i].append(pos)
    return paths


def solve_lacam(grid, agents, max_iterations=LACAM_MAX_ITERATIONS, directions=DIRECTIONS_4, stats=None):
    """Try to solve with LaCAM. Returns list of paths, or None on failure
    (caller decides whether to fall back).

    If `stats` is given, it's updated in place with:
      expanded_nodes    - number of DFS nodes expanded (one per
                           iteration of the search loop below - each
                           is one attempted joint-configuration
                           timestep, LaCAM's equivalent of a "search
                           node")
      replanning_count   - number of backtracks (a joint configuration
                           was abandoned - via a PIBT dead end or a
                           repeated/looping configuration - and the
                           search had to try a different one), LaCAM's
                           equivalent of CBS's per-agent replans
    """
    if not agents:
        return None

    starts = tuple(a["start"] for a in agents)
    goals = tuple(a["goal"] for a in agents)
    n = len(agents)

    if starts == goals:
        return [[s] for s in starts]

    dist_tables = build_distance_tables(grid, list(goals), directions)
    rows, cols = len(grid), len(grid[0]) if grid else 0
    max_timesteps = max_search_time(rows, cols)

    priorities0 = tuple(0.0 for _ in range(n))

    # DFS stack of (config, priorities, path_so_far_configs_set_for_cycle_check)
    root_key = (starts, priorities0)
    stack = [root_key]
    parent = {root_key: None}
    path_configs = {starts}  # configs used along the *current* DFS branch
    depth = {root_key: 0}

    iterations = 0
    while stack and iterations < max_iterations:
        iterations += 1
        if stats is not None:
            stats["expanded_nodes"] = stats.get("expanded_nodes", 0) + 1
        node_key = stack[-1]
        config, priorities = node_key

        if config == goals:
            return _reconstruct(parent, node_key, n)

        if depth[node_key] >= max_timesteps:
            stack.pop()
            path_configs.discard(config)
            if stats is not None:
                stats["replanning_count"] = stats.get("replanning_count", 0) + 1
            continue

        next_config = pibt_timestep(config, priorities, grid, list(goals), dist_tables, directions)

        if next_config is None or next_config in path_configs:
            # PIBT got stuck, or we'd be revisiting a configuration
            # already on this branch (a loop) - dead end, backtrack.
            stack.pop()
            path_configs.discard(config)
            if stats is not None:
                stats["replanning_count"] = stats.get("replanning_count", 0) + 1
            continue

        # Priority update: anyone not yet home waits longer -> higher priority next time.
        next_priorities = tuple(
            0.0 if next_config[i] == goals[i] else priorities[i] + 1.0
            for i in range(n)
        )

        next_key = (next_config, next_priorities)
        parent[next_key] = node_key
        depth[next_key] = depth[node_key] + 1
        stack.append(next_key)
        path_configs.add(next_config)

    return None  # exhausted the budget without reaching the goal config


def solve(grid, agents, max_iterations=LACAM_MAX_ITERATIONS, stats=None):
    """
    Public entry point used by the UI.
    Returns (paths, solver_name, timing) where solver_name is "LaCAM"
    or "CBS (fallback)" (with a " (diagonal)" suffix if 4-directional
    movement alone couldn't solve the instance), or (None, None, timing)
    if neither could solve it even with diagonal movement enabled.
    timing is {"lacam_time": seconds, "cbs_time": seconds} - kept
    separate so a Performance Evaluation report can compare them, the
    same way hybrid_solver.py tracks its own stage timings.

    4-directional movement is tried first for both LaCAM and its CBS
    fallback - it's the default, more "physical" movement model. Only
    if *both* fail under that model do we widen to 8-directional
    (diagonal) movement and try the whole thing again from scratch.

    If `stats` is given, it's updated in place with the combined
    "expanded_nodes" / "replanning_count" across whichever stage(s)
    actually ran (LaCAM, then CBS fallback if needed) - see
    solve_lacam() and cbs.py's cbs() for what each counts.
    """
    timing = {"lacam_time": 0.0, "cbs_time": 0.0}

    for directions, suffix in ((DIRECTIONS_4, ""), (DIRECTIONS_8, " (diagonal)")):

        t0 = time.perf_counter()
        paths = solve_lacam(grid, agents, max_iterations, directions, stats=stats)
        timing["lacam_time"] += time.perf_counter() - t0
        if paths is not None:
            return paths, "LaCAM" + suffix, timing

        t0 = time.perf_counter()
        fallback_paths = run_cbs(grid, agents, directions=directions, stats=stats)
        timing["cbs_time"] += time.perf_counter() - t0
        if fallback_paths is not None:
            return fallback_paths, "CBS (fallback)" + suffix, timing

    return None, None, timing
